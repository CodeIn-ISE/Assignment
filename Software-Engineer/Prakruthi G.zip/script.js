
 document.addEventListener("DOMContentLoaded", function() {
     const widgets = document.querySelectorAll('.dashboard-widget');
     widgets.forEach((widget, index) => {
         setTimeout(() => {
             widget.classList.add('animate');
         }, index * 300); // Adjust the delay (300ms in this example)
     });
 });
 document.addEventListener("DOMContentLoaded", function() {
     const widgets = document.querySelectorAll('.dashboard-widget');
     widgets.forEach((widget, index) => {
         setTimeout(() => {
             widget.classList.add('animate');
         }, index * 300); // Adjust the delay (300ms in this example)
     });
 })
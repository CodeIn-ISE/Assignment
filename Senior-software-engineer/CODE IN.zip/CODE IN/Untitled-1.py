numbers = int(input("Enter the number you want to print: "))
output = "{"
count = 0
for i in range(1, numbers + 1):
    if i % 3 == 0 and i % 5 == 0:
        output += "FizzBuzz, "
    elif i % 3 == 0:
        output += "Fizz, "
    elif i % 5 == 0:
        output += "buzz, "
    else:
        output += str(i) + ", "

    count += 1
    if count == 5:
        output = output + "\n "
        count = 0
output = output+"}"
print(output)